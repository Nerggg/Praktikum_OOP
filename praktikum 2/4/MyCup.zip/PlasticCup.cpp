#include "PlasticCup.hpp"
#include "Glass.hpp"
#include "Cup.hpp"

bool PlasticCup::is_usable() {
    return (this->Plastic::is_usable() and this->current_microplastics < this->maximum_microplastics);
}

void PlasticCup::fill(int volume, enum WaterType type) {
    this->Cup::fill(volume, type);
    this->Plastic::use();
    int terurai = this->Plastic::shred_microplastics(Cup::get_water_volume(), Cup::capacity);
    if(type == HOT_WATER){
        terurai *= 2;
        this->current_microplastics += terurai;
    }
    else{
        this->current_microplastics += terurai;
    }
}

void PlasticCup::drink(int volume) {
    if(this->Plastic::is_usable()){
        this->Cup::drink(volume);
        this->Plastic::use();
        if(this->current_microplastics - volume < 0){
            this->current_microplastics = 0;
        }
        else{
            this->current_microplastics -= volume;
        }
    }
}

void PlasticCup::drop(int height) {
    if (height < 0 || height > 100) {
        return;
    }
    this->current_microplastics += this->shred_microplastics(this->Cup::get_water_volume() * height, this->capacity);
}
