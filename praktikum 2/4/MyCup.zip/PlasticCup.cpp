#include "PlasticCup.hpp"
#include "Glass.hpp"
#include "Cup.hpp"

bool PlasticCup::is_usable() {
    return this->Plastic::is_usable();
}

void PlasticCup::fill(int volume, enum WaterType type) {
    this->Cup::fill(volume, type);
}

void PlasticCup::drink(int volume) {
    this->Cup::drink(volume);
}

void PlasticCup::drop(int height) {
    if (height < 0 || height > 100) {
        return;
    }
    this->current_microplastics += this->shred_microplastics(this->Cup::get_water_volume() * height, this->capacity);
}