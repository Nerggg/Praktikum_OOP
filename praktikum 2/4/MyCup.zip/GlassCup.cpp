#include "GlassCup.hpp"
#include "Glass.hpp"
#include "Cup.hpp"

bool GlassCup::is_usable() {
    return this->Glass::is_usable();
}

void GlassCup::fill(int volume, enum WaterType type) {
    if (is_usable()) {
        this->Cup::fill(volume, type);
    }
}

void GlassCup::drink(int volume) {
    if (is_usable()) {
        this->Cup::drink(volume);
    }
}

void GlassCup::drop(int height) {
    if (height < 0 || height > 100) {
        return;
    }
    
    if (this->Cup::get_water_volume() == 0) {
        this->Glass::apply_force(height);
    }
    else {
        this->Glass::apply_force(this->Cup::get_water_volume() * height);
    }
}
