#include "GlassCup.hpp"
#include "Glass.hpp"
#include "Cup.hpp"

bool GlassCup::is_usable() {
    return this->Glass::is_usable();
}

void GlassCup::fill(int volume, enum WaterType type) {
    this->Cup::fill(volume, type);
}

void GlassCup::drink(int volume) {
    this->Cup::drink(volume);
}

void GlassCup::drop(int height) {
    if (height < 0 || height > 100) {
        return;
    }
    
    if (this->Cup::get_water_volume() == 0) {
        this->apply_force(height);
    }
    else {
        this->apply_force(this->Cup::get_water_volume() * height);
    }
}