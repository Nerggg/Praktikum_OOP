#include "AppreciatingAsset.hpp"

double power(double angka, int power);
//     double res = 1;
//     for (int i = 0; i < power; i++) {
//         res *= angka;
//     }
//     return res;
// }
// AppreciatingAsset::AppreciatingAsset(Asset* x, double rate) {
//     this->x = x;
//     this->rate = rate;
// }

double AppreciatingAsset::getValue(int years) {
    return (this->x->getValue(years) * power(1 + this->rate, years));
}