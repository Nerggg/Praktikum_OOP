#include "DepreciatingAsset.hpp"

double power(double angka, int power) {
    double res = 1;
    for (int i = 0; i < power; i++) {
        res *= angka;
    }
    return res;
}
// DepreciatingAsset::DepreciatingAsset(Asset* x, double rate) {
//     this->x = x;
//     this->rate = rate;
// }

double DepreciatingAsset::getValue(int years) {
    return (this->x->getValue(years) * power(1 - this->rate, years));
}